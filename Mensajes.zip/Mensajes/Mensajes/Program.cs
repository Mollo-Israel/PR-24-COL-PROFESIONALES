namespace Mensajes
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            // Cambiar la ruta predeterminada para que apunte a CreateReminder en el controlador Reminder
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Reminder}/{action=CreateReminder}/{id?}");

            app.Run();
        }
    }
}