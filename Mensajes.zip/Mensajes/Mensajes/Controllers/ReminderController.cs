﻿using Microsoft.AspNetCore.Mvc;
using Mensajes.Models;
using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

public class MessagingServiceController : Controller
{
    private readonly string _twilioAccountSid = "ACf918b72ca94a352ebb292affc9e1eef6"; // Tu Account SID
    private readonly string _twilioAuthToken = "ba08c056474a1e7053b30058e980fa46"; // Tu Auth Token
    private readonly string _whatsappFromNumber = "whatsapp:+14155238886"; // Número de WhatsApp de Twilio
    private readonly string _smsFromNumber = "+12132050901"; // Tu número de Twilio para SMS

    public MessagingServiceController()
    {
        TwilioClient.Init(_twilioAccountSid, _twilioAuthToken);
    }

    public IActionResult CreateReminder()
    {
        return View();
    }

    [HttpPost]
    public IActionResult CreateReminder(ReminderFormModel model, string serviceType)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        if (!model.PhoneNumber.StartsWith("+591"))
        {
            ModelState.AddModelError("PhoneNumber", "El número debe estar en formato internacional (+591).");
            return View(model);
        }

        // Enviar el mensaje según el tipo de servicio
        try
        {
            if (serviceType == "WhatsApp")
            {
                SendWhatsAppMessage(model.PhoneNumber, model.Message);
            }
            else // Asume SMS si no es WhatsApp
            {
                SendSmsMessage(model.PhoneNumber, model.Message);
            }

            ViewBag.SuccessMessage = "Recordatorio enviado exitosamente.";
        }
        catch (Exception ex)
        {
            ModelState.AddModelError("", $"Error al enviar el mensaje: {ex.Message}");
        }

        return View();
    }

    private void SendWhatsAppMessage(string to, string message)
    {
        // Simulación del envío de WhatsApp
        Console.WriteLine($"WhatsApp Message sent to {to}: {message}");
    }

    private void SendSmsMessage(string to, string message)
    {
        // Asegúrate de que 'to' esté en el formato correcto
        var messageOptions = new CreateMessageOptions(new PhoneNumber(to))
        {
            From = new PhoneNumber(_smsFromNumber), // Número de Twilio
            Body = message,
        };

        var msg = MessageResource.Create(messageOptions);
        Console.WriteLine($"Mensaje enviado: {msg.Sid}");
    }
}
