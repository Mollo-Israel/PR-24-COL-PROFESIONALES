﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Mensajes.Models
{
    public class ReminderFormModel
    {
        [Required]
        [Phone]
        public string PhoneNumber { get; set; }

        [Required]
        public string Message { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime ReminderTime { get; set; }
    }
}
